import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (Estiben Gomez) 
 * @version (this is the untillionth version 5/6/2019)
 */
public class MyWorld extends World
{
    // instance variables
    
    GreenfootImage background;
    
    //////////////////////////
    
    GreenfootSound song;
    
    //////////////////////////
    
    ///health bar variables///
    
    healthBar bar = new healthBar();
    healthBar2 bar2 = new healthBar2(); // 1st zombie
    healthBar3 bar3 = new healthBar3(); // 2nd zombie
    healthBar4 bar4 = new healthBar4(); // Boss 
    
   
    //////////////////////////
    
    /////character variables //////
    Zombie zom = new Zombie();  // 1st zombie
    Zombie2 zom2 = new Zombie2(); // 2nd zombie
    Boss boss = new Boss(); // Boss
    Ninja nin = new Ninja(); // Ninja
    
    
    /**
     * Constructor for objects of class MyWorld.
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 500, 1); 
        prepare();
        
        song = new GreenfootSound("sounds/Hypnotic-Puzzle.mp3");
    }
    
    public void prepare()
    {
        background = new GreenfootImage("images/BG.png");
        setBackground(background);
        /////////////////////////////////////////////////
        
        //////////// flooring ///////////////////////////
        addObject(new Floor(), 65,500);
        addObject(new Floor1(), 190,500);
        addObject(new Floor1(), 318,500);
        addObject(new Floor1(), 445,500);
        addObject(new Floor1(), 570,500);
        addObject(new Floor1(), 690,500);
        addObject(new Floor1(), 815,500);
        addObject(new Floor2(), 935,500);
        //////////////////////////////////////////////////
        
        //////// health bars//////////////////////////////
        addObject(bar, 55,30);
        showText("NINJA", 55, 11);
        addObject(bar2, 945, 30);
        showText("ZOMBIE", 945, 11);
        //////////////////////////////////////////////////
        
        /////////// characters ///////////////////////////
        addObject(nin, 200, 375);
        addObject(zom, 945, 375);
        
        //////////////////////////////////////////////////
    }
    
    /////////////character health methods////////////////
    public healthBar getHealthBar() ///// ninja health ////////
    {
        return bar;
    }
    
    public healthBar2 getHealthBar2()   ///// zombie health ///////
    {
        return bar2;
    }
    
    public healthBar3 getHealthBar3()
    {
        return bar3;
    }
    
    public healthBar4 getHealthBar4()
    {
        return bar4;
    }
    /////////////////////////////////////////////////////////
    
    
    ///////////// add and track enemy count /////////////////
    
    public void enemytrack()
    {
        if (zom.zombiecount == 0)
        {
            addObject(bar3, 945, 30);
            showText("ZOMBIE 2", 945, 11);
            addObject(zom2, 945, 375);
            
            
        }
        
        if(zom2.zombiecount1 == 0)
        {
            removeObject(zom2);
            
            addObject(bar4, 945, 30);
            showText("BOSS", 945, 11);
            addObject(boss, 945, 370);
        }
        
        
    }
    
    //////////////////////////////////////////////////////////
    
    //////////////world act method //////////////////////////
    
    public void act()
    {
        
        enemytrack();
        
        
    }
    
    public void started()
    {
        song.playLoop();
        
    }
    
    public void stopped()
    {
        song.stop();
        
    }
}
