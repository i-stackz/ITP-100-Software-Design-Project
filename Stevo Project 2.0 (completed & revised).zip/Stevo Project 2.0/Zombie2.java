
import greenfoot.*;

/**
 * Write a description of class Zombie2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Zombie2  extends Actor
{
    // instance variables
    int GRAVITY = 2;
    int velocity;
    int zombiecount1;
    
    healthBar bar;
    healthBar3 bar3;
    
    //// image variables //////
    
    GreenfootImage image0;
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    GreenfootImage image4;
    GreenfootImage image5;
    GreenfootImage image6;
    GreenfootImage image7;
    GreenfootImage image8;
    GreenfootImage image9;
    int frame;
    ////////////////////////////
    
    /**
     * Constructor for objects of class Zombie2
     */
    public Zombie2()
    {
        image0 = new GreenfootImage("ZombieMaleEnemy/IdleL1.png");
        setImage(image0);
        frame = 0;
        velocity = 0;
        
        zombiecount1 = 1;
        
        
    }
   
    
    //////////// animation methods /////////////
    public void walkL()
    {
        image0 = new GreenfootImage("ZombieFemaleEnemy/WalkL1.png");
        image1 = new GreenfootImage("ZombieFemaleEnemy/WalkL2.png");
        image2 = new GreenfootImage("ZombieFemaleEnemy/WalkL3.png");
        image3 = new GreenfootImage("ZombieFemaleEnemy/WalkL4.png");
        image4 = new GreenfootImage("ZombieFemaleEnemy/WalkL5.png");
        image5 = new GreenfootImage("ZombieFemaleEnemy/WalkL6.png");
        image6 = new GreenfootImage("ZombieFemaleEnemy/WalkL7.png");
        image7 = new GreenfootImage("ZombieFemaleEnemy/WalkL8.png");
        image8 = new GreenfootImage("ZombieFemaleEnemy/WalkL9.png");
        image9 = new GreenfootImage("ZombieFemaleEnemy/WalkL10.png");
        
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame = frame +1;
    }
    
    public void attackA()
    {
        image0 = new GreenfootImage("ZombieFemaleEnemy/AttackL1.png");
        image1 = new GreenfootImage("ZombieFemaleEnemy/AttackL2.png");
        image2 = new GreenfootImage("ZombieFemaleEnemy/AttackL3.png");
        image3 = new GreenfootImage("ZombieFemaleEnemy/AttackL4.png");
        image4 = new GreenfootImage("ZombieFemaleEnemy/AttackL5.png");
        image5 = new GreenfootImage("ZombieFemaleEnemy/AttackL6.png");
        image6 = new GreenfootImage("ZombieFemaleEnemy/AttackL7.png");
        image7 = new GreenfootImage("ZombieFemaleEnemy/AttackL8.png");
        
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
            frame = 0;
        }
        frame = frame + 1;
    }
    
    public void death()
    {
        image0 = new GreenfootImage("ZombieFemaleEnemy/DeadL1.png");
        image1 = new GreenfootImage("ZombieFemaleEnemy/DeadL2.png");
        image2 = new GreenfootImage("ZombieFemaleEnemy/DeadL3.png");
        image3 = new GreenfootImage("ZombieFemaleEnemy/DeadL4.png");
        image4 = new GreenfootImage("ZombieFemaleEnemy/DeadL5.png");
        image5 = new GreenfootImage("ZombieFemaleEnemy/DeadL6.png");
        image6 = new GreenfootImage("ZombieFemaleEnemy/DeadL7.png");
        image7 = new GreenfootImage("ZombieFemaleEnemy/DeadL8.png");
        image8 = new GreenfootImage("ZombieFemaleEnemy/DeadL9.png");
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        frame = frame + 1;
        setImage(image8);
        setLocation(getX(), 400);
        Greenfoot.delay(40);
    }
    
    /////////////// method for behavior //////////////////
    
    public void ai()
    {
        World world = getWorld();
        MyWorld myworld = (MyWorld) world;
        bar = myworld.getHealthBar();
        bar3 = myworld.getHealthBar3();
        
        if(isTouching(Ninja.class))
        {
            attackA();
            
            Greenfoot.playSound("sounds/slurp.wav");
            bar.loseHealth();
            Greenfoot.delay(20);
        }
           
        
        
        if(getX() == 0)
        {
            setLocation(945, 375);
        }
        
        
        if(bar3.health > 0)
        {
            walkL();
            setLocation(getX() -5, getY());
            Greenfoot.delay(2);
        }
        
        if(bar3.health == 0)
        {
            die();
            bar.health = bar.health +5;
        }
        
    }
    
    /////// die method ////////////////
    public void die()
    {
      
            death();
            Greenfoot.playSound("sounds/Zombie Gibberish.mp3");
            
            
            
            zombiecount1 --;
            
            
            getWorld().removeObject(this);
            
            
    }
    
    ///////////////act method ////////////
    public void act()
    {
        
        ai();
    }
}
