import greenfoot.*;

/**
 * Write a description of class Floor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor  extends Actor
{
    // instance variables - replace the example below with your own
    GreenfootImage floor;
    
    

    /**
     * Constructor for objects of class Floor
     */
    public Floor()
    {
        floor = new GreenfootImage("World/png/Tiles/1.png");
        setImage(floor);
        
        
    }
    
    
}
