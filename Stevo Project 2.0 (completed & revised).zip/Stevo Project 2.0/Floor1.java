import greenfoot.*;

/**
 * Write a description of class Floor1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor1  extends Actor
{
    // instance variables - replace the example below with your own
    GreenfootImage floor;
    
    

    /**
     * Constructor for objects of class Floor1
     */
    public Floor1()
    {
        floor = new GreenfootImage("World/png/Tiles/2.png");
        setImage(floor);
        
        
    }
    
    
}
