
import greenfoot.*;

/**
 * Write a description of class Zombie here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Zombie  extends Actor
{
    // instance variables
    int GRAVITY = 2;
    int velocity;
    int zombiecount;
    
    healthBar bar;
    healthBar2 bar2;
    
    //// image variables //////
    
    GreenfootImage image0;
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    GreenfootImage image4;
    GreenfootImage image5;
    GreenfootImage image6;
    GreenfootImage image7;
    GreenfootImage image8;
    GreenfootImage image9;
    int frame;
    ////////////////////////////
    
    /**
     * Constructor for objects of class Zombie
     */
    public Zombie()
    {
        image0 = new GreenfootImage("ZombieMaleEnemy/IdleL1.png");
        setImage(image0);
        frame = 0;
        velocity = 0;
        
        zombiecount = 1;
        
        
    }
    
    ////// Gravity Method///////
    
    public void fall()
    {
       setLocation(getX(),getY() + velocity);
        
        if(getY() > getWorld().getHeight()) velocity = 0;
        else if(isTouching(Floor.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor1.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor2.class) == false)
        {
            velocity += GRAVITY;
        }
        
        if(isTouching(Floor.class) == true)
        {
            setLocation(getX(),375);
        }
        
        if(isTouching(Floor1.class) == true)
        {
            setLocation(getX(),375);
        }
        
        if(isTouching(Floor2.class) == true)
        {
            setLocation(getX(),375);
        } 
    }
    
    //////////// animation methods /////////////
    public void walkL()
    {
        image0 = new GreenfootImage("ZombieMaleEnemy/WalkL1.png");
        image1 = new GreenfootImage("ZombieMaleEnemy/WalkL2.png");
        image2 = new GreenfootImage("ZombieMaleEnemy/WalkL3.png");
        image3 = new GreenfootImage("ZombieMaleEnemy/WalkL4.png");
        image4 = new GreenfootImage("ZombieMaleEnemy/WalkL5.png");
        image5 = new GreenfootImage("ZombieMaleEnemy/WalkL6.png");
        image6 = new GreenfootImage("ZombieMaleEnemy/WalkL7.png");
        image7 = new GreenfootImage("ZombieMaleEnemy/WalkL8.png");
        image8 = new GreenfootImage("ZombieMaleEnemy/WalkL9.png");
        image9 = new GreenfootImage("ZombieMaleEnemy/WalkL10.png");
        
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame = frame +1;
    }
    
    public void attackA()
    {
        image0 = new GreenfootImage("ZombieMaleEnemy/AttackL1.png");
        image1 = new GreenfootImage("ZombieMaleEnemy/AttackL2.png");
        image2 = new GreenfootImage("ZombieMaleEnemy/AttackL3.png");
        image3 = new GreenfootImage("ZombieMaleEnemy/AttackL4.png");
        image4 = new GreenfootImage("ZombieMaleEnemy/AttackL5.png");
        image5 = new GreenfootImage("ZombieMaleEnemy/AttackL6.png");
        image6 = new GreenfootImage("ZombieMaleEnemy/AttackL7.png");
        image7 = new GreenfootImage("ZombieMaleEnemy/AttackL8.png");
        
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
            frame = 0;
        }
        frame = frame + 1;
    }
    
    public void death()
    {
        image0 = new GreenfootImage("ZombieMaleEnemy/DeadL1.png");
        image1 = new GreenfootImage("ZombieMaleEnemy/DeadL2.png");
        image2 = new GreenfootImage("ZombieMaleEnemy/DeadL3.png");
        image3 = new GreenfootImage("ZombieMaleEnemy/DeadL4.png");
        image4 = new GreenfootImage("ZombieMaleEnemy/DeadL5.png");
        image5 = new GreenfootImage("ZombieMaleEnemy/DeadL6.png");
        image6 = new GreenfootImage("ZombieMaleEnemy/DeadL7.png");
        image7 = new GreenfootImage("ZombieMaleEnemy/DeadL8.png");
        image8 = new GreenfootImage("ZombieMaleEnemy/DeadL9.png");
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        frame = frame + 1;
        setImage(image8);
        setLocation(getX(), 400);
        Greenfoot.delay(40);
    }
    
    /////////////// method for behavior //////////////////
    
    public void ai()
    {
        World world = getWorld();
        MyWorld myworld = (MyWorld) world;
        bar = myworld.getHealthBar();
        bar2 = myworld.getHealthBar2();
        
        
        
        if(isTouching(Ninja.class))
        {
               
             attackA();
             Greenfoot.playSound("sounds/slurp.wav");
             bar.loseHealth();
             Greenfoot.delay(20);
        }
           
        
        
        if(getX() == 0)
        {
            setLocation(945, 375);
        }
        
        
        if(bar2.health > 0)
        {
            walkL();
            setLocation(getX() -5, getY());
            Greenfoot.delay(2);
        }
        
        if(bar2.health == 0)
        {
            die();
            bar.health = bar.health +5;
        }
        
    }
    
    /////// die method ////////////////
    public void die()
    {
      
            death();
            Greenfoot.playSound("sounds/Zombie Long Death.mp3");
            //myworld.showText("You Win", 500, 200);
            
            
            zombiecount --;
            
            
            getWorld().removeObject(this);
            
        
    }
    
    ///////////////act method ////////////
    public void act()
    {
        
        ai();
    }
}
