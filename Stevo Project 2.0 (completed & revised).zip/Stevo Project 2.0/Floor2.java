import greenfoot.*;

/**
 * Write a description of class Floor2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor2  extends Actor
{
    // instance variables - replace the example below with your own
    GreenfootImage floor;
    
    

    /**
     * Constructor for objects of class Floor2
     */
    public Floor2()
    {
        floor = new GreenfootImage("World/png/Tiles/3.png");
        setImage(floor);
        
        
    }
    
    
}
