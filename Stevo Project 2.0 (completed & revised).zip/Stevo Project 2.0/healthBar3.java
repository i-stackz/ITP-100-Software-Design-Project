

import greenfoot.*;

/**
 * Write a description of class healthBar3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class healthBar3  extends Actor
{
    // instance variables - replace the example below with your own
    int health = 2;
    int healthBarWidth = 100;
    int healthBarHeight = 15;
    int pixelsPerHealthPoint = (int)healthBarWidth/health;
    
    

    /**
     * Constructor for objects of class healthBar3
     */
    public healthBar3()
    {
        update();
       
    }

    public void act()
    {
        update();
        
    }
    
    public void update()
    {
        setImage(new GreenfootImage(healthBarWidth + 2, healthBarHeight +2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.BLACK);
        myImage.drawRect(0,0, healthBarWidth +1, healthBarHeight +1);
        myImage.setColor(Color.PINK);
        myImage.fillRect(1, 1, health*pixelsPerHealthPoint, healthBarHeight);
    }
    
    public void loseHealth()
    {
        health --;
        
    }
}
