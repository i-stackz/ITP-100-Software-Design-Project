import greenfoot.*;
/**
 * Write a description of class Boss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss  extends Actor
{
    // instance variables//
    int GRAVITY = 2;
    int velocity;

    //////// image variables //////
    GreenfootImage image0;
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    GreenfootImage image4;
    GreenfootImage image5;
    GreenfootImage image6;
    GreenfootImage image7;
    GreenfootImage image8;
    GreenfootImage image9;
    int frame;
    /////////////////////////////////

    ////// health bar variables /////////
    healthBar bar;  // ninja
    healthBar4 bar4; // boss

    


    /**
     * Constructor for objects of class Boss
     */
    public Boss()
    {
        frame = 0;
        velocity = 0;
        image0 = new GreenfootImage("RobotBoss/IdleL1.png");
        setImage(image0);

    }

    ////// Gravity Method///////

    public void fall()
    {
        setLocation(getX(),getY() + velocity);

        if(getY() > getWorld().getHeight()) velocity = 0;
        else if(isTouching(Floor.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor1.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor2.class) == false)
        {
            velocity += GRAVITY;
        }

        if(isTouching(Floor.class) == true)
        {
            setLocation(getX(),375);
        }

        if(isTouching(Floor1.class) == true)
        {
            setLocation(getX(),375);
        }

        if(isTouching(Floor2.class) == true)
        {
            setLocation(getX(),375);
        } 
    }

    ///////////////////////////////

    /// animations /////////////

    public void idle()
    {
        image0 = new GreenfootImage("RobotBoss/IdleL1.png");
        image1 = new GreenfootImage("RobotBoss/IdleL2.png");
        image2 = new GreenfootImage("RobotBoss/IdleL3.png");
        image3 = new GreenfootImage("RobotBoss/IdleL4.png");
        image4 = new GreenfootImage("RobotBoss/IdleL5.png");
        image5 = new GreenfootImage("RobotBoss/IdleL6.png");
        image6 = new GreenfootImage("RobotBoss/IdleL7.png");
        image7 = new GreenfootImage("RobotBoss/IdleL8.png");
        image8 = new GreenfootImage("RobotBoss/IdleL9.png");
        image9 = new GreenfootImage("RobotBoss/IdleL10.png");
        Greenfoot.delay(3);

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void jump()
    {
        image0 = new GreenfootImage("RobotBoss/JumpL1.png");
        image1 = new GreenfootImage("RobotBoss/JumpL2.png");
        image2 = new GreenfootImage("RobotBoss/JumpL3.png");
        image3 = new GreenfootImage("RobotBoss/JumpL4.png");
        image4 = new GreenfootImage("RobotBoss/JumpL5.png");
        image5 = new GreenfootImage("RobotBoss/JumpL6.png");
        image6 = new GreenfootImage("RobotBoss/JumpL7.png");
        image7 = new GreenfootImage("RobotBoss/JumpL8.png");
        image8 = new GreenfootImage("RobotBoss/JumpL9.png");
        image9 = new GreenfootImage("RobotBoss/JumpL10.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;

    }

    public void attack()
    {
        image0 = new GreenfootImage("RobotBoss/MeleeL1.png");
        image1 = new GreenfootImage("RobotBoss/MeleeL2.png");
        image2 = new GreenfootImage("RobotBoss/MeleeL3.png");
        image3 = new GreenfootImage("RobotBoss/MeleeL4.png");
        image4 = new GreenfootImage("RobotBoss/MeleeL5.png");
        image5 = new GreenfootImage("RobotBoss/MeleeL6.png");
        image6 = new GreenfootImage("RobotBoss/MeleeL7.png");
        image7 = new GreenfootImage("RobotBoss/MeleeL8.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
            frame = 0;
        }

        frame ++;
    }

    public void shoot()
    {
        image0 = new GreenfootImage("RobotBoss/ShootL1.png");
        image1 = new GreenfootImage("RobotBoss/ShootL2.png");
        image2 = new GreenfootImage("RobotBoss/ShootL3.png");
        image3 = new GreenfootImage("RobotBoss/ShootL4.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
            frame = 0;
        }
        frame ++;
    }

    public void death()
    {
        image0 = new GreenfootImage("RobotBoss/DeadL1.png");
        image1 = new GreenfootImage("RobotBoss/DeadL2.png");
        image2 = new GreenfootImage("RobotBoss/DeadL3.png");
        image3 = new GreenfootImage("RobotBoss/DeadL4.png");
        image4 = new GreenfootImage("RobotBoss/DeadL5.png");
        image5 = new GreenfootImage("RobotBoss/DeadL6.png");
        image6 = new GreenfootImage("RobotBoss/DeadL7.png");
        image7 = new GreenfootImage("RobotBoss/DeadL8.png");
        image8 = new GreenfootImage("RobotBoss/DeadL9.png");
        image9 = new GreenfootImage("RobotBoss/DeadL10.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
        setImage(image9);
        setLocation(getX(),400);
    }

    public void runL()
    {
        image0 = new GreenfootImage("RobotBoss/RunL1.png");
        image1 = new GreenfootImage("RobotBoss/RunL2.png");
        image2 = new GreenfootImage("RobotBoss/RunL3.png");
        image3 = new GreenfootImage("RobotBoss/RunL4.png");
        image4 = new GreenfootImage("RobotBoss/RunL5.png");
        image5 = new GreenfootImage("RobotBoss/RunL6.png");
        image6 = new GreenfootImage("RobotBoss/RunL7.png");
        image7 = new GreenfootImage("RobotBoss/RunL8.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
            frame = 0;
        }
        frame ++;
    }

    ///// behavior ///////////

    public void ai()
    {
        World world = getWorld();
        MyWorld myworld = (MyWorld) world;
        bar = myworld.getHealthBar();
        bar4 = myworld.getHealthBar4();
        
        //idle();
        /////////// experiment ///////////
        Shot shot = new Shot();
        if(Greenfoot.getRandomNumber(5000)<300)
        {
            shoot();
            getWorld().addObject(shot, getX(), getY());
            Greenfoot.playSound("sounds/Laser Cannon.mp3");
        }
        
        //////////////////////////////////

        setLocation(getX()-10,getY());
        runL();
        
        
        if(Greenfoot.getRandomNumber(2000)<100 && getY() > getWorld().getHeight() - 300)
        {
            jump();
            Greenfoot.playSound("sounds/spin jump.mp3");
            velocity = -15;
        }
        
        if(getX() == 0)
        {
            setLocation(945, 370);
        }

        if(isTouching(Ninja.class))
        {
            attack();
            Greenfoot.playSound("sounds/Lightsaber.mp3");
            bar.loseHealth();
        }

        if(bar4.health == 0)
        {
            death();
            Greenfoot.playSound("sounds/au.wav");
            Greenfoot.stop();
            world.showText("YOU WIN", 500, 200);
            Greenfoot.playSound("sounds/Ta Da.mp3");
        }
    }

    //////////////////////////

    ////////act method ///////

    public void act()
    {
        fall();
        ai();
    }

    /////////////////////////
}
