import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Shot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shot extends Actor
{
    
    //// instance variables /////
    GreenfootImage image0;
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    int frame;
    /////////////////////////////
    
    /////// constructor /////////
    public Shot()
    {
        frame = 0;
    }
    
    /////////////////////////////
    
    public void blast()
    {
        image0 = new GreenfootImage("images/RobotBoss/Objects/Muzzle_000.png");
        image1 = new GreenfootImage("images/RobotBoss/Objects/Muzzle_001.png");
        image2 = new GreenfootImage("images/RobotBoss/Objects/Muzzle_002.png");
        image3 = new GreenfootImage("images/RobotBoss/Objects/BulletL0.png");
        
        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if (frame == 2)
        {
            setImage(image2);
        }
        else if (frame == 3)
        {
            setImage(image3);
            
        }
        frame ++;
        
        
        
    }
   
    public void move()
    {   
        setLocation(getX()-50,getY());
    }
    
    public void damage()
    {
        World world = getWorld();
        MyWorld myworld = (MyWorld) world;
        healthBar bar = myworld.getHealthBar();
        
        
        if(isTouching(Ninja.class))
        {
            bar.loseHealth();
        }
        
        if(getX() == 0)
        {
            myworld.removeObject(this);
        }
    }
    
    public void act() 
    {
        blast();
        move();
        damage();
    }    
}
