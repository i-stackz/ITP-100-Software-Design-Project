
import greenfoot.*;

/**
 * Write a description of class Ninja here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ninja  extends Actor
{
    ///// instance variables //////
    int GRAVITY = 2;
    int velocity;

    //////// image variables //////

    GreenfootImage image0;
    GreenfootImage image1;
    GreenfootImage image2;
    GreenfootImage image3;
    GreenfootImage image4;
    GreenfootImage image5;
    GreenfootImage image6;
    GreenfootImage image7;
    GreenfootImage image8;
    GreenfootImage image9;
    int frame;
    /////////////////////////////////

    /////enemy healthBar Variable /////

    healthBar bar;
    healthBar2 bar2;
    healthBar3 bar3;
    healthBar4 bar4;

    ///////////////////////////////////

    /**
     * Ninja Constructor
     */
    public Ninja()
    {
        frame = 0;
        velocity = 0;
        image0 = new GreenfootImage("Ninja/Idle__000.png");
        setImage(image0);

    }

    ////// Gravity Method///////

    public void fall()
    {
        setLocation(getX(),getY() + velocity);

        if(getY() > getWorld().getHeight()) velocity = 0;
        else if(isTouching(Floor.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor1.class) == false)
        {
            velocity += GRAVITY;
        }
        else if(isTouching(Floor2.class) == false)
        {
            velocity += GRAVITY;
        }

        if(isTouching(Floor.class) == true)
        {
            setLocation(getX(),375);
        }

        if(isTouching(Floor1.class) == true)
        {
            setLocation(getX(),375);
        }

        if(isTouching(Floor2.class) == true)
        {
            setLocation(getX(),375);
        } 
    }

    /// animations /////////////

    public void idle()
    {
        image0 = new GreenfootImage("Ninja/Idle__000.png");
        image1 = new GreenfootImage("Ninja/Idle__001.png");
        image2 = new GreenfootImage("Ninja/Idle__002.png");
        image3 = new GreenfootImage("Ninja/Idle__003.png");
        image4 = new GreenfootImage("Ninja/Idle__004.png");
        image5 = new GreenfootImage("Ninja/Idle__005.png");
        image6 = new GreenfootImage("Ninja/Idle__006.png");
        image7 = new GreenfootImage("Ninja/Idle__007.png");
        image8 = new GreenfootImage("Ninja/Idle__008.png");
        image9 = new GreenfootImage("Ninja/Idle__009.png");
        Greenfoot.delay(3);

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void jump()
    {
        image0 = new GreenfootImage("Ninja/Jump__000.png");
        image1 = new GreenfootImage("Ninja/Jump__001.png");
        image2 = new GreenfootImage("Ninja/Jump__002.png");
        image3 = new GreenfootImage("Ninja/Jump__003.png");
        image4 = new GreenfootImage("Ninja/Jump__004.png");
        image5 = new GreenfootImage("Ninja/Jump__005.png");
        image6 = new GreenfootImage("Ninja/Jump__006.png");
        image7 = new GreenfootImage("Ninja/Jump__007.png");
        image8 = new GreenfootImage("Ninja/Jump__008.png");
        image9 = new GreenfootImage("Ninja/Jump__009.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void runningR()
    {
        image0 = new GreenfootImage("Ninja/RUN__000.PNG");
        image1 = new GreenfootImage("Ninja/RUN__001.PNG");
        image2 = new GreenfootImage("Ninja/RUN__002.PNG");
        image3 = new GreenfootImage("Ninja/RUN__003.PNG");
        image4 = new GreenfootImage("Ninja/RUN__004.PNG");
        image5 = new GreenfootImage("Ninja/RUN__005.PNG");
        image6 = new GreenfootImage("Ninja/RUN__006.PNG");
        image7 = new GreenfootImage("Ninja/RUN__007.PNG");
        image8 = new GreenfootImage("Ninja/RUN__008.PNG");
        image9 = new GreenfootImage("Ninja/RUN__009.PNG");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void runningL()
    {
        image0 = new GreenfootImage("Ninja/RunL0.png");
        image1 = new GreenfootImage("Ninja/RunL1.png");
        image2 = new GreenfootImage("Ninja/RunL2.png");
        image3 = new GreenfootImage("Ninja/RunL3.png");
        image4 = new GreenfootImage("Ninja/RunL4.png");
        image5 = new GreenfootImage("Ninja/RunL5.png");
        image6 = new GreenfootImage("Ninja/RunL6.png");
        image7 = new GreenfootImage("Ninja/RunL7.png");
        image8 = new GreenfootImage("Ninja/RunL8.png");
        image9 = new GreenfootImage("Ninja/RunL9.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void attack()
    {
        image0 = new GreenfootImage("Ninja/Attack__000.png");
        image1 = new GreenfootImage("Ninja/Attack__001.png");
        image2 = new GreenfootImage("Ninja/Attack__002.png");
        image3 = new GreenfootImage("Ninja/Attack__003.png");
        image4 = new GreenfootImage("Ninja/Attack__004.png");
        image5 = new GreenfootImage("Ninja/Attack__005.png");
        image6 = new GreenfootImage("Ninja/Attack__006.png");
        image7 = new GreenfootImage("Ninja/Attack__007.png");
        image8 = new GreenfootImage("Ninja/Attack__008.png");
        image9 = new GreenfootImage("Ninja/Attack__009.png");

        if(frame == 0)
        {
            setImage(image0);
        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);
            frame = 0;
        }
        frame ++;
    }

    public void dead()
    {
        image0 = new GreenfootImage("Ninja/Dead__000.png");
        image1 = new GreenfootImage("Ninja/Dead__001.png");
        image2 = new GreenfootImage("Ninja/Dead__002.png");
        image3 = new GreenfootImage("Ninja/Dead__003.png");
        image4 = new GreenfootImage("Ninja/Dead__004.png");
        image5 = new GreenfootImage("Ninja/Dead__005.png");
        image6 = new GreenfootImage("Ninja/Dead__006.png");
        image7 = new GreenfootImage("Ninja/Dead__007.png");
        image8 = new GreenfootImage("Ninja/Dead__008.png");
        image9 = new GreenfootImage("Ninja/Dead__009.png");

        if(frame == 0)
        {
            setImage(image0);

        }
        else if(frame == 1)
        {
            setImage(image1);
        }
        else if(frame == 2)
        {
            setImage(image2);
        }
        else if(frame == 3)
        {
            setImage(image3);
        }
        else if(frame == 4)
        {
            setImage(image4);
        }
        else if(frame == 5)
        {
            setImage(image5);
        }
        else if(frame == 6)
        {
            setImage(image6);
        }
        else if(frame == 7)
        {
            setImage(image7);
        }
        else if(frame == 8)
        {
            setImage(image8);
        }
        else if(frame == 9)
        {
            setImage(image9);

        }
        frame ++;
        setImage(image9);
        setLocation(getX(),400);
    }

    ////////////////////////////////////////////////////////

    ////////////damage dealing method and taking method/////

    public void damageEnemy()   // Zombie 
    {
        World myworld = getWorld();
        MyWorld world = (MyWorld) myworld;
        bar2 = world.getHealthBar2();

        bar2.loseHealth();
    }
    
    public void damageEnemy1()  // Zombie 2
    {
        World myworld = getWorld();
        MyWorld world = (MyWorld) myworld;
        bar3 = world.getHealthBar3();

        bar3.loseHealth();
    }
    
    public void damageEnemy2()  //Boss
    {
        World myworld = getWorld();
        MyWorld world = (MyWorld) myworld;
        bar4 = world.getHealthBar4();

        bar4.loseHealth();
    }
    
    public void death()
    {
        World myworld = getWorld();
        MyWorld world = (MyWorld) myworld;
        bar = world.getHealthBar();

        if(bar.health == 0)
        {
            dead();
            Greenfoot.playSound("sounds/Dying.mp3");
            world.showText("Game Over", 500, 200);
            Greenfoot.stop();
            Greenfoot.playSound("sounds/Sad Trombone.mp3");
        }

    }

    ////////////////////////////////////////////

    //////// character control method///////////

    public void checkKeyPress()
    {

        if(Greenfoot.isKeyDown("left"))
        {
            runningL();
            setLocation(getX()-15, getY());
            Greenfoot.delay(1);
        }

        if(Greenfoot.isKeyDown("right"))
        {
            runningR();
            setLocation(getX()+15, getY());
            Greenfoot.delay(1);
        }

        if(Greenfoot.isKeyDown("up") && getY() > getWorld().getHeight() - 300)
        {
            jump();
            Greenfoot.playSound("sounds/Jump.mp3");
            velocity = -15;
            Greenfoot.delay(2);
        }

        if(Greenfoot.isKeyDown("space"))
        {
            attack();
            Greenfoot.playSound("sounds/Jab.mp3");

            if(isTouching(Zombie.class))
            {
                damageEnemy();
            }

            if(isTouching(Zombie2.class))
            {
                damageEnemy1();
            }
            
            if(isTouching(Boss.class))
            {
                damageEnemy2();
            }
        }
    }

    ///////////////////////////////

    //////////act method///////////

    public void act()
    {
        fall();
        idle();
        checkKeyPress();
        death();

    }
}
